LoudCloud Notifier
==================

Instructions for V. A1
Run LCN_GUI setup to make conf file
Run LCN to start notification and monitoring
Profit!!

Features
--------
Notifies you if you have a new LoudCloud notification
Currently only on computer

TODO list
---------
	Add support for forum and class wall
	Add support for adding own class_ids
	Add build support
	Add some cool graphics
